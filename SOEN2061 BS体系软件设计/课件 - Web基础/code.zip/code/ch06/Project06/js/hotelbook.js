window.onload = function () {
  var gallery = document.getElementsByClassName("gallery");   //缩略图区块
  //注册缩略图单击事件
  var imgs = gallery[0].getElementsByTagName("img");
  obj = gallery[0].getElementsByTagName("ul")[0];
  //复制缩略图列表，实现无缝滚动
  obj.innerHTML += obj.innerHTML;
  for (i = 0; i < imgs.length; i++) {
    /*实现单击缩略图显示该图片的清晰大图*/
    imgs[i].onclick = function () {
      url = this.src;
      roomimg = document.getElementsByClassName("roomimg");
      roomimg[0].getElementsByTagName("img")[0].src = url; 
    }
  }
  var prev = document.getElementById("prev");   //向上箭头按钮
  var next = document.getElementById("next");   //向下箭头按钮
  /*注册向上箭头按钮单击事件，实现缩略图向上滚动*/
  prev.onclick = function () {
    if (flag) {
      speed = 1;
      flag = false;
      timer = setInterval("move(-1)", 30);
    }
  };
  /*注册向下箭头按钮单击事件，实现缩略图向下滚动*/
  next.onclick = function () {
    if (flag) {
      speed = 1;
      flag = false;
      timer = setInterval("move(1)", 30);
    }
  };  
  /*注册确认预订按钮单击事件*/
  document.getElementById("chkReserve").onclick = function () {
    closepopDiv();
    alert("预订成功！");
  }
  /*注册取消预订按钮单击事件*/
  document.getElementById("cancelReserve").onclick = function () {
    closepopDiv();
  }
}
/*定义图片滚动方法，实现图片滚动*/
var speed;	//移动距离
var timer;	//setInterval()返回值，用于取消setInterval()
var obj;		//缩略图列表
var flag = true;	//标签，记录用户一次单击滚动是否完成，true表示已完成，false表示未完成 
function move(step) {
  if (speed <= 82) {		//speed<=82表示一张图片的滚动还未完成
    //向上滚动，所有缩略图均移出画廊区域时，缩略图列表恢复初始位置
    if (obj.offsetTop < -(obj.offsetHeight / 2)) {
      obj.style.top = 0;
    }
    //向下移动，画廊区域上方没有图片时，定位缩略图位置
    if (obj.offsetTop > 0) { 
      obj.style.top = -(obj.offsetHeight / 2) + 'px';
    }
    obj.style.top = obj.offsetTop + step + 'px';
    speed++;
  }
  else {	
//一张图片的滚动已完成，取消setInterval()，初始化滚动参数
    clearInterval(timer);
    speed = 1;
    flag = true;
   }
}
/*客房筛选*/
var cond = ["", "", ""]		//初始化筛选分类，数据项为空表示该分类无筛选条件
function filterroom(cls, clsname, type) {
  cond[type] = clsname;	//设置对应分类的筛选条件
  var str;  //筛选分类名
  switch (type) {
    case 0: str = "roomtype"; break;
    case 1: str = "havebreakfast"; break;
    case 2: str = "paytype"; break;
  }
  //初始化筛选分类为str下所有筛选条件文本颜色
  var opts = document.getElementsByClassName(str)[0].getElementsByTagName("a");
  for (i = 0; i < opts.length; i++) {
    opts[i].style.color = "#666";
  }
  //设置选中的筛选条件文本颜色
  cls.style.color = "#925f0c";
  //设置所有客房信息不可见
  rooms = document.getElementsByClassName("room");
  for (i = 0; i < rooms.length; i++) {
    rooms[i].style.display = "none";
  }
  //获取符合筛选条件的客房信息，并将其设置为可见
  result = document.getElementsByClassName(cond.join(" "));
  for (j = 0; j < result.length; j++) {
    result[j].style.display = "block";
  }
}
/*客房预订*/
function reserve(btnReserve) {
  //计算遮罩层的位置，并弹出显示 
  var mask = document.getElementById("mask");
  if (document.body.offsetWidth >= 1160)
    mask.style.width = document.body.offsetWidth + "px";
  else
    mask.style.width = "1160px";
mask.style.height = document.body.clientHeight + "px";
  mask.style.display = "block";
  //计算客房预订信息对话框的位置，并弹出显示
  var reserveinfo = document.getElementById("reserveinfo");
  reserveinfo.style.display = "block";
  reserveinfo.style.left = (window.innerWidth - reserveinfo.clientWidth) / 2 + "px";
  reserveinfo.style.top = (window.innerHeight - reserveinfo.clientHeight) / 2 + "px";
  //获取预订信息，并将其写入客房预订信息对话框
  var person = document.getElementsByTagName("header")[0].getElementsByTagName("span")[0].innerHTML;
  var starttime = document.getElementById("starttime").value;
  var endtime = document.getElementById("endtime").value;
  var roomnum = document.getElementById("roomnum").value;
  var room = btnReserve.parentNode.parentNode;
  var roomtype = room.getElementsByClassName("roompic")[0].getElementsByTagName("p")[0].innerHTML;
  var havebreakfast = room.classList[1];
  var price = room.getElementsByClassName("reserve")[0].getElementsByTagName("span")[0].innerHTML;
  document.getElementById("stime").innerText = starttime;
  document.getElementById("etime").innerText = endtime;
  document.getElementById("nums").innerText = roomnum;
  document.getElementById("rtype").innerText = roomtype;
  if (havebreakfast == "breakfast")
    document.getElementById("rtype").innerText += "（含早）";
  else
    document.getElementById("rtype").innerText += "（不含早）";
  document.getElementById("moneypernight").innerText = price + "元/晚"
  var days = (Date.parse(endtime) - Date.parse(starttime)) / (24 * 3600 * 1000);
  document.getElementById("sum").innerText = "￥" + days * price.substring(1) * roomnum + "元";
}
/*关闭遮罩层和客房预订信息对话框*/
function closepopDiv() {
  document.getElementById("mask").style.display = "none";
  document.getElementById("reserveinfo").style.display = "none";
}
