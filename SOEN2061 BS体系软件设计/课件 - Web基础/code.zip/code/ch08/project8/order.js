//初始化已选菜品数据对象
var selected_dishes={"dishes":[{"id":"dish_4","name":"口水鸡","count":1}]};
//遍历并绑定添加菜品按钮事件
var dish_button=document.getElementsByClassName("add_dish");            
for(var i=0;i<dish_button.length;i++){
    dish_button[i].addEventListener("click",function(){
        var dish_name=document.getElementsByClassName(this.classList[2])[0]
        var exist_tag=false;
        //判断要添加的菜品是否已经在已选菜单中，如果存在则份数加1
        for(var i in selected_dishes.dishes){
            var selected_dish=selected_dishes.dishes[i];
            if(selected_dish.name===dish_name.textContent){
                selected_dish.count+=1;
                exist_tag=true;
                break;
            }
        }
        //如果菜品不在已选菜单中，则添加到菜单，并更新已选菜品数量
        if (!exist_tag){
            selected_dishes.dishes.push({"id":dish_name.classList[1],"name":dish_name.textContent,"count":1});
            refresh_selected_list_count();
        }
    });   
}

// 绑定已选菜品菜单按钮事件
var selected_list_button=document.getElementsByClassName("selected_list_button")[0];
var selected_list=document.getElementsByClassName("selected_list")[0];
selected_list_button.addEventListener("click",function(){
    selected_list.classList.toggle("hidden");
    document.getElementsByClassName("modal")[0].classList.toggle("hidden");
    refresh_selected_list();
});

// 绑定点击切换菜品类型事件
var dish_type=document.getElementsByClassName("dish_type");        
for(var i=0;i<dish_type.length;i++){
    dish_type[i].addEventListener("click",function(){
        var dish_type_active=document.getElementsByClassName("dish_type_active")[0];
        dish_type_active.classList.remove("dish_type_active");
        this.classList.toggle("dish_type_active")
    });
}

// 重新渲染已选菜品菜单
function refresh_selected_list(){
    document.getElementsByClassName("selected_list")[0].innerHTML="";
    for(var i in selected_dishes.dishes){
        var selected_dish=selected_dishes.dishes[i];
        var html="<div class='selected_dish'><div class='selected_dish_name'>"+
            selected_dish["name"]+"</div><div class='selected_dish_count'>"+
                "<button type='button' class='sub_dish_count "+selected_dish["id"]+"'>-</button>x<span>"+selected_dish["count"]+"</span>"+
                "<button type='button' class='add_dish_count "+selected_dish["id"]+"' >+</button>"+
                "</div></div>"
        document.getElementsByClassName("selected_list")[0].innerHTML+=html;
    }
    //动态绑定加减已选菜品份数按钮事件
    var add_dish_count=document.getElementsByClassName("add_dish_count");
    var sub_dish_count=document.getElementsByClassName("sub_dish_count");
    for(var i=0;i<add_dish_count.length;i++){
        add_dish_count[i].addEventListener("click",function(){
            var current_id=this.classList[1];
            refresh_data(current_id,1);
            refresh_selected_list();
        });
        sub_dish_count[i].addEventListener("click",function(){
            var current_id=this.classList[1];
            refresh_data(current_id,-1);
            refresh_selected_list();
            refresh_selected_list_count();
        });
    }
}
//更新已选菜品数量
function refresh_selected_list_count(){
    document.getElementById("selected_dishes_count").innerHTML=selected_dishes.dishes.length;
}
//更新已选菜品数据
function refresh_data(current_id,opertator){
    for(var i in selected_dishes.dishes){
        var selected_dish=selected_dishes.dishes[i];
        if(selected_dish.id===current_id){
            selected_dish.count+=opertator;
            //如果份数为0，从列表中去除
            if(selected_dish.count==0){
                selected_dishes.dishes.splice(i, 1);
            }
            break;
        }
    }
}
