console.log("JS已加载")
//----------输入验证---------------
//---用户名验证---
var username = document.getElementsByName("Username")[0];
//使用ES6 Arrow Function方式绑定元素onblur事件函数
username.onblur = () => {  // 例如在输入焦点离开时进行验证
    username.checkValidity();
    
}
//用户名不合法时提醒
function usernameInvalid(){
    username.setCustomValidity('用户名长度为3-12位英文字母和数字，首字母不能是数字！');
    alert(username.validationMessage); // 验证结果信息在元素的validationMessage属性中
}
//---校验密码---
//校验2次输入是否正确，使用onblur绑定自定义函数
function checkPassword(){
    var first = document.getElementsByName("Password")[0];
    var second= document.getElementsByName("Second_password")[0];
    if (first.value==second.value){
        second.style.borderColor="green";
    }else{
        alert("两次密码不同");
        second.style.borderColor="red";
    }
}

//---email验证---
var email = document.querySelector("#email");
//使用匿名Function方式绑定元素onblur事件函数
email.onblur = function(){
    email.checkValidity(); //激活HTML5验证API
}
//Email不合法时提醒
function emailInvalid(){
    email.setCustomValidity('请填写正确格式的Email！');
    alert(email.validationMessage); // 验证结果信息在元素的validationMessage属性中
}

//dataList功能实现Email输入提示，函数通过HTML onchange属性绑定
function emailHint() {
    //获取email输入的值
    var email = document.getElementById("email").value;
    //获取dataList对象
    var email_hint = document.getElementById("email_hint");
    //清空原有的值
    email_hint.innerHTML = ""
    //如果不为空且没有@则生成提示
    if(email.indexOf("@")==-1 && email!=""){
        email_hint.innerHTML = "<option value='" + email + "@qq.com'></option>" +
        "<option value='" + email + "@163.com'></option>" +
        "<option value='" + email + "@gmail.com'></option>"
    }
}
//---头像上传校验---
//只在提交时提醒
function portraitInvalid(){
    var portrait=document.getElementsByName("Upload")[0]
    portrait.setCustomValidity('请上传头像！');
    alert(portrait.validationMessage); 
    portrait.setCustomValidity('');
}

//上传照片
function uploadFile(){
    document.getElementsByName("Upload")[0].click();
}

//显示照片,此处仅模拟上传成功后显示图片
function changeFile(){
    document.getElementById("portrait").src="portrait.png";
}



//-------可以承受的价格范围更新----------
var Price = document.getElementsByName("Price")[0];
//使用ES6 Arrow Function方式绑定元素onblur事件函数
Price.onmousemove = () => {  // 例如在输入焦点离开时进行验证
    document.getElementById("price").innerHTML=Price.value
}


