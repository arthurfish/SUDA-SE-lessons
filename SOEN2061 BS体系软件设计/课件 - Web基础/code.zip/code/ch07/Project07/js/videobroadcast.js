var vd;
var originwidth;
var originheight;
window.onload = function () {
vd = document.getElementById("vd");   //获取video对象
  var currentTime = vd.currentTime;     //获取视频当前时间
var totalTime = vd.duration;          //获取视频总时长
/*将视频当前时间和总时长格式化后写入对应的对象中*/
  document.getElementById("currentTime").innerHTML = formatTime(currentTime);
document.getElementById("totalTime").innerHTML = formatTime(totalTime);
  document.getElementById("videoProgress").max = totalTime;  //设置视频进度条完成值
  vd.volume = 0.5;  //初始化视频音量
  originwidth = document.getElementById("player").clientWidth; //计算视频播放器宽度
  originheight =document.getElementById("player").clientHeight;//计算视频播放器宽度
}
/*格式化视频时间，格式为00:00*/
function formatTime(time) {
  var m = Math.floor(time % 3600 / 60);
  var s = Math.floor(time % 60);
  m = m >= 10 ? m : "0" + m;
  s = s >= 10 ? s : "0" + s;
  return m + ":" + s;
}
var timer;
/*播放视频*/
function play() {
  vd.play();
  timer = setInterval(readVideo, 1000)
}
/*根据视频播放时间，修改时间显示*/
function readVideo() {
  document.getElementById("currentTime").innerHTML = formatTime(vd.currentTime);
  document.getElementById("videoProgress").value = vd.currentTime;
}
/*暂停视频*/
function pause() {
  vd.pause();
  clearInterval(timer);
}
/*设置倍速*/
function playspeed(obj) {
  var text = obj.innerText;
  var speed = text.substring(0, text.length - 1);
  vd.playbackRate = speed;
}
/*全屏*/
var flag = 0  //是否全屏，1表示全屏，0表示非全屏
function fullscreen() {
  var player = document.getElementById("player");
  var btnFullScreen = document.getElementById("btnFullScreen");
  if (flag == 0) {
    player.style.width = document.documentElement.clientWidth + "px";
    player.style.height = document.documentElement.clientHeight + "px";
    player.style.position = "fixed";
    player.style.zIndex=9999;
    btnFullScreen.src = "images/cancelfull.png";
    flag = 1;
  }
  else {
    player.style.width = originwidth + "px";
    player.style.height = originheight + "px";
    player.style.position = "relative";
    player.style.zIndex=0;
    btnFullScreen.src = "images/fullscreen.png";
    flag = 0
  }
}
/*静音切换*/
var isVolume = 0;  //静音标识，0表示静音，1表示非静音
function switchVolume() {
if (isVolume == 0) {
    document.getElementById("btnVolume").src = "images/volumeCross.png";
    vd.muted = true;
    isVolume = 1;
  }
  else {
    document.getElementById("btnVolume").src = "images/volume.png";
    vd.muted = false;
    isVolume = 0;
  }
}
//改变音量
function changeVolume(num) {
  if (vd.volume + num < 1 && vd.volume + num > 0) {
    vd.volume = vd.volume + num;
    document.getElementById("volumeProgress").value = vd.volume;
  }
  else {
    if (num > 0)
      document.getElementById("volumeProgress").value = 1;
  }
}
var ischeck=0;  //是否操作标识，0表示未操作，1表示已操作
//每次单击交互按钮，获取用户的操作标识，此处虚拟用户尚未操作，值为0
function isClick(obj){
  brotherNode=obj.parentNode.children[1];
  if(ischeck==0){
    obj.style.backgroundPositionY="0px";
    brotherNode.innerText=parseInt(brotherNode.innerText)+1;
    ischeck=1;
  }
  else{
    obj.style.backgroundPositionY="-28px";
    brotherNode.innerText=parseInt(brotherNode.innerText)-1;
    ischeck=0;
  }
}
/*发布评论*/
function pubComment() {
  if (document.getElementById("commentText").value != "" && document.getElementById("commentText").value != "发表评论") {
    var date = new Date();
    var content = document.getElementById("commentText").value;
    var userImg = "images/photo.png";
    var username = "我是一条鱼";
    var text = "<div class='comment'><img src=" + userImg + " alt=''><div><p class='commentname'>" + username + "</p><p class='content'>" + content + "</p><p class='commentinfo'>" + date.toLocaleDateString() + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds() + "</p></div></div>"
    document.getElementById("comments").innerHTML += text;
  }
}
