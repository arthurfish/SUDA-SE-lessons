﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PyIDE
{
    public partial class FormObject : Form
    {
        private List<ExplorerItem> list;

        public FormObject(List<ExplorerItem> list)
        {
            InitializeComponent();

            this.list = list;

            foreach (ExplorerItem item in list)
            {
                listBox1.Items.Add(item.title);
            }
        }
    }
}
