﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PyIDE
{
    public enum ExplorerItemType
    {
        Class, Method, Property, Event
    }

    public class ExplorerItem
    {
        public ExplorerItemType type;
        public string title;
        public int position;
    }
}
