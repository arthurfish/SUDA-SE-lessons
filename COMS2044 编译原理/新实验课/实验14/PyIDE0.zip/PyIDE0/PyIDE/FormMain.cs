﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FastColoredTextBoxNS;
using System.Text.RegularExpressions;
using System.IO;
using System.Diagnostics;

namespace PyIDE
{
    public partial class FormMain : Form
    {

        #region Style

        TextStyle BlueStyle = new TextStyle(Brushes.Blue, null, FontStyle.Regular);
        TextStyle BoldStyle = new TextStyle(null, null, FontStyle.Bold | FontStyle.Underline);
        TextStyle GrayStyle = new TextStyle(Brushes.Gray, null, FontStyle.Regular);
        TextStyle MagentaStyle = new TextStyle(Brushes.Magenta, null, FontStyle.Regular);
        TextStyle GreenStyle = new TextStyle(Brushes.Green, null, FontStyle.Italic);
        TextStyle BrownStyle = new TextStyle(Brushes.Brown, null, FontStyle.Italic);
        TextStyle MaroonStyle = new TextStyle(Brushes.Maroon, null, FontStyle.Regular);
        MarkerStyle SameWordsStyle = new MarkerStyle(new SolidBrush(Color.FromArgb(40, Color.Gray)));

        #endregion

        AutocompleteMenu popupMenu;
        

        private string filename;

        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            InitAutoComplete();

        }

        private void InitAutoComplete()
        {
            string[] keywords = { "class", "struct", "enum", "interface", "False", "None", "True", "and", "as", "assert", "async", "await", "break", "class", "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return", "try", "while", "with", "yield", "abs", "all", "any", "ascii", "bin", "bool", "breakpoint", "bytearray", "bytes", "callable", "chr", "classmethod", "compile", "complex", "copyright", "credits", "delattr", "dict", "dir", "divmod", "enumerate", "eval", "exec", "exit", "filter", "float", "format", "frozenset", "getattr", "globals", "hasattr", "hash", "help", "hex", "id", "input", "int", "isinstance", "issubclass", "iter", "len", "license", "list", "locals", "map", "max", "memoryview", "min", "next", "object", "oct", "open", "ord", "pow", "print", "property", "quit", "range", "repr", "reversed", "round", "set", "setattr", "slice", "sorted", "staticmethod", "str", "sum", "super", "tuple", "type", "vars", "zip" };
            //create autocomplete popup menu
            popupMenu = new AutocompleteMenu(fctb);
            popupMenu.MinFragmentLength = 2;
            //size of popupmenu
            popupMenu.Items.MaximumSize = new System.Drawing.Size(200, 300);
            popupMenu.Items.Width = 200;

            //set words as autocomplete source
            popupMenu.Items.SetAutocompleteItems(keywords);
        }


        private void fctb_TextChanged(object sender, TextChangedEventArgs e)
        {
            PythonHighlight(e);

            //InitAutoComplete();

           
        }


        private void PythonHighlight(TextChangedEventArgs e)
        {
            fctb.LeftBracket = '(';
            fctb.RightBracket = ')';
            fctb.LeftBracket2 = '\x0';
            fctb.RightBracket2 = '\x0';
            //clear style of changed range


            e.ChangedRange.ClearStyle(BlueStyle, BoldStyle, GrayStyle, MagentaStyle, GreenStyle, BrownStyle);

            //string highlighting
            e.ChangedRange.SetStyle(BrownStyle, @"""""|@""""|''|@"".*?""|(?<!@)(?<range>"".*?[^\\]"")|'.*?[^\\]'");
            //comment highlighting
            e.ChangedRange.SetStyle(GreenStyle, @"#.*$", RegexOptions.Multiline);
            //number highlighting
            e.ChangedRange.SetStyle(MagentaStyle, @"\b\d+[\.]?\d*([eE]\-?\d+)?[lLdDfF]?\b|\b0x[a-fA-F\d]+\b");
            //class name highlighting
            e.ChangedRange.SetStyle(BoldStyle, @"\b(class|struct|enum|interface)\s+(?<range>\w+?)\b");
            //keyword highlighting
            e.ChangedRange.SetStyle(BlueStyle, @"\b(False|None|True|and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield)\b");
            // buildin highlighting
            e.ChangedRange.SetStyle(GrayStyle, @"\b(abs|all|any|ascii|bin|bool|breakpoint|bytearray|bytes|callable|chr|classmethod|compile|complex|copyright|credits|delattr|dict|dir|divmod|enumerate|eval|exec|exit|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|isinstance|issubclass|iter|len|license|list|locals|map|max|memoryview|min|next|object|oct|open|ord|pow|print|property|quit|range|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|vars|zip)\b");
            //function name highlighting
            e.ChangedRange.SetStyle(GrayStyle, @"\b(def)\s+(?<range>\w+?)\b");


            //set folding markers
            fctb.Range.ClearFoldingMarkers();

            var currentIndent = 0;
            var lastNonEmptyLine = 0;

            for (int i = 0; i < fctb.LinesCount; i++)
            {
                var line = fctb[i];
                var spacesCount = line.StartSpacesCount;
                if (spacesCount == line.Count) //empty line
                    continue;

                if (currentIndent < spacesCount)
                    //append start folding marker
                    fctb[lastNonEmptyLine].FoldingStartMarker = "m" + currentIndent;
                else
                    if (currentIndent > spacesCount)
                        //append end folding marker
                        fctb[lastNonEmptyLine].FoldingEndMarker = "m" + spacesCount;

                currentIndent = spacesCount;
                lastNonEmptyLine = i;
            }
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                this.filename = openFileDialog1.FileName;

                using (StreamReader sr = new StreamReader(this.filename))
                {
                    string text = sr.ReadToEnd();
                    fctb.Text = text;
                }
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            this.filename = "";
            fctb.Text = "";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (this.filename.Length > 0 && fctb.Text.Length > 0)
            {
                saveFile(this.filename, fctb.Text);
            }
            else
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    this.filename = saveFileDialog1.FileName;
                    saveFile(this.filename, fctb.Text);
                }
            }
        }

        private void saveFile(string filename, string text)
        {
            using (StreamWriter sw = new StreamWriter(filename))
            {
                sw.Write(text);
            }
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            if (this.filename.Length > 0)
            {
                saveFile(this.filename, fctb.Text);

                Process myProcess = new Process();
                myProcess.StartInfo.UseShellExecute = false;
                myProcess.StartInfo.RedirectStandardOutput = true;
                myProcess.StartInfo.RedirectStandardError = true;
                myProcess.StartInfo.CreateNoWindow = true;

                myProcess.StartInfo.FileName = "python";
                myProcess.StartInfo.Arguments = this.filename;

                myProcess.Start();
                myProcess.WaitForExit(15000);//等待exe程序处理完，超时15秒
                string result = myProcess.StandardOutput.ReadToEnd();
                string error = myProcess.StandardError.ReadToEnd();

                txtInfo.Text = result+error;
                textboxForce(txtInfo);
            }
        }

        private void textboxForce(TextBox tb)
        {
            

        }

        private void txtInfo_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            
        }

        private string getErrorMessage(TextBox tb, int startLineNum)
        {
            for (int i = startLineNum + 1; i < tb.Lines.Length&&i<startLineNum+5; i++)
            {
                if (tb.Lines[i].ToLower().IndexOf("error")>=0)
                {
                    return tb.Lines[i];
                }
            }

            return "";
        }

        private void btnCut_Click(object sender, EventArgs e)
        {
          
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            
        }

        private void btnPaste_Click(object sender, EventArgs e)
        {
           
        }

        private void btnUndo_Click(object sender, EventArgs e)
        {
            
        }

        private void btnRedo_Click(object sender, EventArgs e)
        {
            
        }

        private List<ExplorerItem> GetObjects(string text)
        {
            List<ExplorerItem> list = new List<ExplorerItem>();

            try
            {
                
                int lastClassIndex = -1;
                //find classes, methods and properties
                Regex regex = new Regex(@"^(?<range>[\w\s]+\b(class|struct|enum|interface)\s+[\w<>,\s]+)|^\s*(def)[^\n]+(\n?\s*{|;)?", RegexOptions.Multiline);
                foreach (Match r in regex.Matches(text))
                    try
                    {
                        string s = r.Value;
                        int i = s.IndexOfAny(new char[] { '=', '{', ';' });
                        if (i >= 0)
                            s = s.Substring(0, i);
                        s = s.Trim();

                        var item = new ExplorerItem() { title = s, position = r.Index };
                        if (Regex.IsMatch(item.title, @"\b(class|struct|enum|interface)\b"))
                        {
                            item.title = item.title.Substring(item.title.LastIndexOf(' ')).Trim();
                            item.type = ExplorerItemType.Class;
                            list.Sort(lastClassIndex + 1, list.Count - (lastClassIndex + 1), new ExplorerItemComparer());
                            lastClassIndex = list.Count;
                        }
                        else
                        {
                            if (item.title.Contains("("))
                            {
                                var parts = item.title.Split('(');
                                item.title = parts[0].Substring(parts[0].LastIndexOf(' ')).Trim() + "(" + parts[1];
                                item.title = item.title.Substring(0, item.title.Length - 1);
                                item.type = ExplorerItemType.Method;
                            }
                            else
                            {
                                if (item.title.EndsWith("]"))
                                {
                                    var parts = item.title.Split('[');
                                    if (parts.Length < 2) continue;
                                    item.title = parts[0].Substring(parts[0].LastIndexOf(' ')).Trim() + "[" + parts[1];
                                    item.type = ExplorerItemType.Method;
                                }
                                else
                                {
                                    int ii = item.title.LastIndexOf(' ');
                                    item.title = item.title.Substring(ii).Trim();
                                    item.type = ExplorerItemType.Property;
                                }
                            }
                        }
                                
                        list.Add(item);
                    }
                    catch { ;}

                list.Sort(lastClassIndex + 1, list.Count - (lastClassIndex + 1), new ExplorerItemComparer());

    
            }
            catch { ;}

            return list;
        }



        class ExplorerItemComparer : IComparer<ExplorerItem>
        {
            public int Compare(ExplorerItem x, ExplorerItem y)
            {
                return x.title.CompareTo(y.title);
            }
        }

        private void btnObject_Click(object sender, EventArgs e)
        {
            List<ExplorerItem> list = GetObjects(fctb.Text);

            FormObject f = new FormObject(list);
            f.ShowDialog();
        }

        private void btnFind_Click(object sender, EventArgs e)
        {

        }

    }
}
